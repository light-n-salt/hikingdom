create table club_join_request
(
    id          bigint unsigned auto_increment
        primary key,
    created_at  datetime(6)     null,
    modified_at datetime(6)     null,
    status      varchar(10)     not null,
    club_id     bigint unsigned not null,
    member_id   bigint unsigned not null
);

INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (1, '2023-05-09 11:42:29.600556', '2023-05-09 13:27:55.068048', 'RETRACTED', 1, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (2, '2023-05-09 11:42:47.081078', '2023-05-09 13:26:24.154057', 'RETRACTED', 2, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (3, '2023-05-09 11:42:59.016582', '2023-05-09 13:18:54.948065', 'RETRACTED', 3, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (4, '2023-05-09 13:37:26.380223', '2023-05-09 13:41:56.649649', 'RETRACTED', 1, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (5, '2023-05-09 13:37:48.259848', '2023-05-09 13:38:14.395930', 'RETRACTED', 2, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (6, '2023-05-09 13:37:59.004624', '2023-05-09 13:38:23.321032', 'RETRACTED', 3, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (7, '2023-05-09 13:45:44.363393', '2023-05-09 14:50:43.374360', 'REJECTED', 1, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (8, '2023-05-09 13:45:53.722881', '2023-05-09 14:51:42.760099', 'RETRACTED', 2, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (9, '2023-05-09 13:46:03.396648', '2023-05-09 14:51:42.760099', 'RETRACTED', 3, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (10, '2023-05-09 14:51:31.049871', '2023-05-09 14:51:42.748534', 'ACCEPTED', 1, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (12, '2023-05-09 20:28:03.704341', '2023-05-14 19:15:32.523430', 'RETRACTED', 1, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (13, '2023-05-09 20:28:12.129817', '2023-05-14 19:15:34.641213', 'RETRACTED', 3, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (14, '2023-05-12 13:28:49.778658', '2023-05-12 14:09:15.856410', 'ACCEPTED', 1, 11);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (15, '2023-05-12 14:52:11.024099', '2023-05-12 14:52:16.698867', 'ACCEPTED', 6, 13);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (16, '2023-05-14 18:32:16.382451', '2023-05-14 18:33:52.988243', 'RETRACTED', 1, 14);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (17, '2023-05-14 18:34:08.270643', '2023-05-14 18:38:32.646656', 'RETRACTED', 1, 14);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (18, '2023-05-14 18:35:33.124089', '2023-05-15 23:02:25.940417', 'RETRACTED', 2, 14);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (19, '2023-05-14 18:35:39.454775', '2023-05-15 23:02:25.940417', 'RETRACTED', 6, 14);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (20, '2023-05-14 19:15:55.900589', '2023-05-14 19:24:25.851026', 'RETRACTED', 1, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (21, '2023-05-14 19:24:48.365823', '2023-05-14 19:25:26.744671', 'RETRACTED', 1, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (22, '2023-05-14 19:25:33.705339', '2023-05-14 19:50:21.823628', 'RETRACTED', 1, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (23, '2023-05-14 19:25:38.150580', '2023-05-14 19:50:22.620494', 'RETRACTED', 2, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (24, '2023-05-14 19:50:53.888386', '2023-05-14 20:08:55.454988', 'RETRACTED', 1, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (25, '2023-05-14 19:51:06.872539', '2023-05-14 20:08:48.782563', 'RETRACTED', 2, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (26, '2023-05-14 20:11:36.571210', '2023-05-16 12:54:38.524482', 'ACCEPTED', 1, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (27, '2023-05-14 20:11:45.931545', '2023-05-14 20:12:07.291059', 'RETRACTED', 2, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (28, '2023-05-14 20:12:29.290770', '2023-05-16 12:54:38.537594', 'RETRACTED', 3, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (29, '2023-05-14 21:17:32.315929', '2023-05-14 21:17:58.391786', 'RETRACTED', 2, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (30, '2023-05-15 08:50:27.673705', '2023-05-15 23:02:25.888849', 'ACCEPTED', 1, 14);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (31, '2023-05-16 14:01:22.214628', '2023-05-22 13:09:06.946515', 'ACCEPTED', 1, 13);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (32, '2023-05-18 12:21:38.084651', '2023-05-18 12:22:16.806524', 'RETRACTED', 1, 17);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (33, '2023-05-18 12:30:16.913232', '2023-05-22 15:13:03.483570', 'RETRACTED', 2, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (34, '2023-05-18 12:30:19.745043', '2023-05-22 15:13:03.483570', 'RETRACTED', 1, 8);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (35, '2023-05-18 13:29:30.222762', '2023-05-18 13:30:13.432449', 'ACCEPTED', 1, 18);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (36, '2023-05-18 13:37:51.161391', '2023-05-18 13:39:59.611573', 'ACCEPTED', 1, 18);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (37, '2023-05-19 01:38:19.127813', '2023-05-19 01:38:30.586713', 'ACCEPTED', 6, 16);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (38, '2023-05-19 01:39:20.465576', '2023-05-19 01:39:47.006054', 'ACCEPTED', 6, 16);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (39, '2023-05-22 11:56:35.464857', '2023-06-02 01:00:44.153260', 'REJECTED', 1, 19);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (40, '2023-05-22 11:56:45.888405', '2023-05-22 11:56:45.888405', 'PENDING', 2, 19);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (41, '2023-05-22 11:56:52.207289', '2023-05-22 11:56:52.207289', 'PENDING', 6, 19);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (42, '2023-05-22 13:32:25.827079', '2023-05-22 13:33:14.158169', 'ACCEPTED', 1, 20);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (43, '2023-05-22 13:53:00.076040', '2023-05-22 13:53:06.305531', 'ACCEPTED', 8, 20);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (44, '2023-05-23 12:30:35.871528', '2023-05-23 12:31:42.880370', 'ACCEPTED', 1, 20);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (45, '2023-05-23 12:57:56.762249', '2023-05-23 12:58:13.483211', 'ACCEPTED', 1, 15);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (46, '2023-06-01 16:28:40.666918', '2023-06-01 20:05:08.724282', 'RETRACTED', 10, 22);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (47, '2023-06-01 16:45:21.671061', '2023-06-02 01:00:32.794982', 'ACCEPTED', 1, 22);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (48, '2023-06-01 16:45:27.074720', '2023-06-01 20:03:45.384646', 'RETRACTED', 2, 22);
INSERT INTO hikingdom.club_join_request (id, created_at, modified_at, status, club_id, member_id) VALUES (49, '2023-06-02 12:11:54.800122', '2023-06-02 12:12:22.610926', 'ACCEPTED', 1, 22);
