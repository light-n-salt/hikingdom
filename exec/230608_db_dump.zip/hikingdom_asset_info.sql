create table asset_info
(
    id            bigint unsigned auto_increment
        primary key,
    asset_url     varchar(512)    not null,
    get_condition varchar(512)    not null,
    name          varchar(50)     not null,
    mountain_id   bigint unsigned not null
);

INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (0, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/main.gltf', '기본 땅', '땅', 0, 0);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (1, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower1.gltf', '가리산 첫 완등', '가리산 첫 등산 기념 에셋', 270, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (2, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower2.gltf', '가지산 첫 완등', '가지산 첫 등산 기념 에셋', 130, 4);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (3, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower3.gltf', '강천산 첫 완등', '강천산 첫 등산 기념 에셋', 300, 6);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (4, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower4.gltf', '계룡산 첫 완등', '계룡산 첫 등산 기념 에셋', 300, 7);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (5, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower5.gltf', '계방산 첫 완등', '계방산 첫 등산 기념 에셋', 225, 8);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (6, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower6.gltf', '금산 첫 완등', '금산 첫 등산 기념 에셋', 240, 12);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (7, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower7.gltf', '금정산 첫 완등', '금정산 첫 등산 기념 에셋', 270, 15);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (8, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower8.gltf', '깃대봉 첫 완등', '깃대봉 첫 등산 기념 에셋', 285, 16);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (9, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower9.gltf', '남산(금오산) 첫 완등', '남산(금오산) 첫 등산 기념 에셋', 300, 17);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (10, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower10.gltf', '도봉산 첫 완등', '도봉산 첫 등산 기념 에셋', 240, 27);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (11, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower11.gltf', '두타산 첫 완등', '두타산 첫 등산 기념 에셋', 180, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (12, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower12.gltf', '두타산 첫 완등', '두타산 첫 등산 기념 에셋', 150, 29);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (13, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower13.gltf', '명지산 첫 완등', '명지산 첫 등산 기념 에셋', 180, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (14, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower14.gltf', '무등산 첫 완등', '무등산 첫 등산 기념 에셋', 240, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (15, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower15.gltf', '명성산 첫 완등', '명성산 첫 등산 기념 에셋', 180, 32);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (16, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower16.gltf', '명지산 첫 완등', '명지산 첫 등산 기념 에셋', 180, 33);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (17, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower17.gltf', '모악산 첫 완등', '모악산 첫 등산 기념 에셋', 240, 34);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (18, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower18.gltf', '무등산 첫 완등', '무등산 첫 등산 기념 에셋', 360, 35);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (19, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower19.gltf', '내장산 첫 완등 첫 완등', '내장산 첫 등산 기념 에셋 첫 등산 기념 에셋', 300, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (20, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower20.gltf', '방장산 첫 완등', '방장산 첫 등산 기념 에셋', 240, 39);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (21, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower21.gltf', '지리산 첫 완등', '지리산 첫 등산 기념 에셋', 210, 42);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (22, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower22.gltf', '대야산 첫 완등 첫 완등', '대야산 첫 등산 기념 에셋 첫 등산 기념 에셋', 300, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (23, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower23.gltf', '장안산 첫 완등', '장안산 첫 등산 기념 에셋', 90, 45);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (24, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower24.gltf', '덕유산 첫 완등 첫 완등', '덕유산 첫 등산 기념 에셋 첫 등산 기념 에셋', 300, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (25, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower25.gltf', '배봉산 첫 완등', '배봉산 첫 등산 기념 에셋', 210, 46);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (26, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower26.gltf', '도락산 첫 완등 첫 완등', '도락산 첫 등산 기념 에셋 첫 등산 기념 에셋', 240, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (27, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree8.gltf', '도봉산 첫 완등', '도봉산 첫 등산 기념 에셋', 210, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (28, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower28.gltf', '두륜산 첫 완등', '두륜산 첫 등산 기념 에셋', 300, 28);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (29, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower29.gltf', '마니산 첫 완등', '마니산 첫 등산 기념 에셋', 420, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (30, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower30.gltf', '마니산 첫 완등', '마니산 첫 등산 기념 에셋', 150, 30);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (31, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower31.gltf', '마이산 첫 완등', '마이산 첫 등산 기념 에셋', 120, 31);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (32, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower32.gltf', '무학산 첫 완등', '무학산 첫 등산 기념 에셋', 180, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (33, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower33.gltf', '민주지산 첫 완등', '민주지산 첫 등산 기념 에셋', 360, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (34, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower34.gltf', '매봉산 첫 완등', '매봉산 첫 등산 기념 에셋', 240, 49);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (36, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower36.gltf', '무학산 첫 완등', '무학산 첫 등산 기념 에셋', 240, 36);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (37, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower37.gltf', '미륵산 첫 완등', '미륵산 첫 등산 기념 에셋', 120, 37);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (38, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower38.gltf', '민주지산 첫 완등', '민주지산 첫 등산 기념 에셋', 150, 38);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (39, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower39.gltf', '방장산 첫 완등 첫 완등', '방장산 첫 등산 기념 에셋 첫 등산 기념 에셋', 180, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (41, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree9.gltf', '장안근린공원 첫 완등 첫 완등', '장안근린공원 첫 등산 기념 에셋 첫 등산 기념 에셋', 20, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (42, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower39.gltf', '응봉산 첫 완등', '응봉산 첫 등산 기념 에셋', 108, 47);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (43, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower42.gltf', '멀티캠퍼스 첫 완등', '멀티캠퍼스 첫 등산 기념 에셋', 20, 48);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (44, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree1.gltf', '북한산 첫 완등', '북한산 첫 등산 기념 에셋', 1708, 43);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (45, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree2.gltf', '지리산 첫 완등 첫 완등', '지리산 첫 등산 기념 에셋 첫 등산 기념 에셋', 1915, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (46, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower47.gltf', '북한산 첫 완등 첫 완등', '북한산 첫 등산 기념 에셋 첫 등산 기념 에셋', 836, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (47, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower4.gltf', '덕항산 첫 완등', '덕항산 첫 등산 기념 에셋', 240, 25);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (48, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower6.gltf', '덕유산 첫 완등', '덕유산 첫 등산 기념 에셋', 240, 24);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (49, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree7.gltf', '덕숭산(수덕산) 첫 완등', '덕숭산(수덕산) 첫 등산 기념 에셋', 240, 23);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (50, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower8.gltf', '대야산 첫 완등', '대야산 첫 등산 기념 에셋', 240, 22);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (51, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree10.gltf', '배봉산 첫 완등', '배봉산 첫 등산 기념 에셋', 300, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (52, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower2.gltf', '응봉산 첫 완등', '응봉산 첫 등산 기념 에셋', 300, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (53, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/flower30.gltf', '멀티캠퍼스 첫 완등', '멀티캠퍼스 첫 등산 기념 에셋', 300, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (54, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree29.gltf', '무등산 5번째 완등 첫 완등', '무등산 5번째 완등 첫 등산 기념 에셋', 300, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (55, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree10.gltf', '무등산 6번째 완등 첫 완등', '무등산 6번째 완등 첫 등산 기념 에셋', 300, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (56, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree18.gltf', '대둔산 2번째 완등 첫 완등', '대둔산 2번째 등산 기념 에셋 첫 등산 기념 에셋', 879, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (57, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree19.gltf', '감악산 첫 완등', '감악산 첫 등산 기념 에셋', 1446, 5);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (58, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree22.gltf', '대암산 첫 완등', '대암산 첫 등산 기념 에셋', 632, 21);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (59, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree23.gltf', '금수산 첫 완등', '금수산 첫 등산 기념 에셋', 845, 13);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (60, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree24.gltf', '도봉산 2번째 완등', '도봉산 2번째 등산 기념 에셋', 740, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (61, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree26.gltf', '가야산 첫 완등', '가야산 첫 등산 기념 에셋', 1593, 3);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (62, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree29.gltf', '공작산 첫 완등', '공작산 첫 등산 기념 에셋', 675, 9);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (63, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree30.gltf', '내연산 첫 완등', '내연산 첫 등산 기념 에셋', 887, 18);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (64, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree10.gltf', '설악산 첫 완등', '설악산 첫 등산 기념 에셋', 879, 44);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (65, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree31.gltf', '대둔산 4번째 완등 첫 완등', '대둔산 4번째 등산 기념 에셋 첫 등산 기념 에셋', 879, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (66, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree75.gltf', '가리왕산 첫 완등', '가리왕산 첫 등산 기념 에셋', 1593, 2);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (67, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree32.gltf', '도락산 첫 완등', '도락산 첫 등산 기념 에셋', 632, 26);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (68, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree40.gltf', '관악산 첫 완등', '관악산 첫 등산 기념 에셋', 675, 10);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (69, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree58.gltf', '내장산 첫 완등', '내장산 첫 등산 기념 에셋', 887, 19);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (70, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree49.gltf', '도봉산 3번째 완등 첫 완등', '도봉산 3번째 등산 기념 에셋 첫 등산 기념 에셋', 740, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (71, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree50.gltf', '대둔산 첫 완등', '대둔산 첫 등산 기념 에셋', 887, 20);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (72, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree51.gltf', '도봉산 4번째 완등', '도봉산 4번째 등산 기념 에셋', 740, 1);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (73, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree68.gltf', '금오산 첫 완등', '금오산 첫 등산 기념 에셋', 845, 14);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (74, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree60.gltf', '구병산 첫 완등', '구병산 첫 등산 기념 에셋', 675, 11);
INSERT INTO hikingdom.asset_info (id, asset_url, get_condition, name, score, mountain_id) VALUES (75, 'https://lightnsalt.s3.ap-northeast-2.amazonaws.com/asset/tree60.gltf', '멀티캠퍼스 첫번쨰 완등 첫 완등', '멀티캠퍼스 첫번쨰 등산 기념 에셋 첫 등산 기념 에셋 첫 등산 기념 에셋', 10, 1);
