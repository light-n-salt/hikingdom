create table member_level_info
(
    id              tinyint auto_increment
        primary key,
    description     varchar(50) not null,
    name            varchar(10) not null,
    level_condition int         null
);

INSERT INTO hikingdom.member_level_info (id, description, name, level_condition) VALUES (1, '최초 가입 시', '씨앗', 0);
INSERT INTO hikingdom.member_level_info (id, description, name, level_condition) VALUES (2, '등산 횟수 10회 이상', '새싹', 10);
INSERT INTO hikingdom.member_level_info (id, description, name, level_condition) VALUES (3, '등산 횟수 20회 이상', '잎새', 20);
INSERT INTO hikingdom.member_level_info (id, description, name, level_condition) VALUES (4, '등산 횟수 30회 이상', '가지', 30);
INSERT INTO hikingdom.member_level_info (id, description, name, level_condition) VALUES (5, '등산 횟수 40회 이상', '꽃', 40);
INSERT INTO hikingdom.member_level_info (id, description, name, level_condition) VALUES (6, '등산 횟수 50회 이상', '열매', 50);
INSERT INTO hikingdom.member_level_info (id, description, name, level_condition) VALUES (7, '등산 횟수 60회 이상', '나무', 60);
INSERT INTO hikingdom.member_level_info (id, description, name, level_condition) VALUES (8, '등산 횟수 70회 이상', '숲', 70);
INSERT INTO hikingdom.member_level_info (id, description, name, level_condition) VALUES (9, '등산 횟수 80회 이상', '산', 80);
INSERT INTO hikingdom.member_level_info (id, description, name, level_condition) VALUES (10, '등산 횟수 90회 이상', '산신령', 90);
