create table member_hiking_statistic
(
    id                   bigint unsigned          not null
        primary key,
    total_alt            int unsigned default '0' not null,
    total_distance       int unsigned default '0' not null,
    total_duration       int unsigned default '0' not null,
    total_hiking_count   int unsigned default '0' not null,
    total_mountain_count int unsigned default '0' not null,
    constraint FKs81d67mvfrevmpfofssst2u15
        foreign key (id) references member (id)
);

INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (1, 115759, 1652010, 85882, 233, 110);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (2, 20800, 721190, 648900, 94, 88);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (3, 12480, 404197, 363600, 39, 30);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (4, 823, 12673, 547, 3, 3);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (6, 13320, 178216, 5971, 16, 11);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (7, 1698, 25346, 1102, 6, 6);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (8, 660, 15961, 3258, 4, 0);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (9, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (10, 3198, 48845, 19574, 41, 22);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (11, 80, 80, 80, 9, 9);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (12, 2598, 26546, 2101, 9, 8);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (13, 22910, 41270, 6606, 43, 37);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (14, 12731, 209383, 5897, 18, 16);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (15, 2501, 39100, 1660, 9, 8);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (16, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (17, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (18, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (19, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (20, 515, 3884, 21491, 26, 14);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (21, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (22, 0, 0, 0, 0, 0);
INSERT INTO hikingdom.member_hiking_statistic (id, total_alt, total_distance, total_duration, total_hiking_count, total_mountain_count) VALUES (23, 0, 0, 0, 0, 0);
