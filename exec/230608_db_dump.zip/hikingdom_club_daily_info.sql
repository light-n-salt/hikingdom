create table club_daily_info
(
    id       bigint unsigned auto_increment
        primary key,
    set_date date            null,
    club_id  bigint unsigned not null
);

INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (3, '2023-05-09', 3);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (4, '2023-05-10', 1);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (5, '2023-05-11', 5);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (6, '2023-05-12', 5);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (7, '2023-05-13', 3);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (8, '2023-05-14', 2);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (9, '2023-05-15', 1);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (10, '2023-05-16', 1);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (11, '2023-05-17', 3);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (14, '2023-05-18', 1);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (15, '2023-05-19', 1);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (17, '2023-05-21', 1);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (18, '2023-05-22', 1);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (19, '2023-05-23', 1);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (20, '2023-05-24', 1);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (21, '2023-05-25', 1);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (22, '2023-05-26', 1);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (23, '2023-05-27', 1);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (24, '2023-05-28', 1);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (25, '2023-05-29', 1);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (26, '2023-05-30', 1);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (27, '2023-05-31', 9);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (28, '2023-06-01', 2);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (29, '2023-06-02', 7);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (30, '2023-06-03', 5);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (31, '2023-06-04', 5);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (32, '2023-06-05', 6);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (33, '2023-06-06', 10);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (34, '2023-06-07', 11);
INSERT INTO hikingdom.club_daily_info (id, set_date, club_id) VALUES (35, '2023-06-08', 8);
